#include <QObject>
#include <vector>

class BaseTestSuite : public QObject
{
        Q_OBJECT
    public:
         BaseTestSuite(QObject *parent = nullptr);
         static std::vector<QObject*> & suite();
};
