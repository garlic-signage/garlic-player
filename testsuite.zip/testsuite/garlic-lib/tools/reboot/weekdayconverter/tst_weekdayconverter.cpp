#include "tst_weekdayconverter.hpp"
#include "tools/reboot/weekdayconverter.h"

void TestWeekdayConverter::testConvertWeekDay()
{
    WeekdayConverter TestClass;

   QCOMPARE(TestClass.convertWeekDay("MonDay"), 1);
   QCOMPARE(TestClass.convertWeekDay("tuesday"), 2);
   QCOMPARE(TestClass.convertWeekDay("Wednesday"), 3);
   QCOMPARE(TestClass.convertWeekDay("thursday"), 4);
   QCOMPARE(TestClass.convertWeekDay("Friday"), 5);
   QCOMPARE(TestClass.convertWeekDay("saturday"), 6);
   QCOMPARE(TestClass.convertWeekDay("sunday"), 7);
   QCOMPARE(TestClass.convertWeekDay("notexistsday"), 0);
}

static TestWeekdayConverter TEST_WEEKDAYCONVERTER;
