#include "base_testsuite.hpp"
#include <QtTest/QtTest>
#include <gtest/gtest.h>


/**
 * Tocreate a TestSuite like normal TestsUnits we use the approach of
 * https://alexhuszagh.github.io/2016/using-qttest-effectively/
 *
 * @brief main
 * @param argc
 * @param argv
 * @return
 */
int main(int argc, char **argv)
{
    int status = 0;
    auto runTest = [&status, argc, argv](QObject* obj)
    {
        status |= QTest::qExec(obj, argc, argv);
    };

    // run suite
    auto &suite = BaseTestSuite::suite();
    for (auto it = suite.begin(); it != suite.end(); ++it)
    {
        runTest(*it);
    }

    return status;

}
